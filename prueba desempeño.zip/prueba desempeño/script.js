function getUsers() {
  const res = fetch("http://localhost:3000/users");
  const data = res.json();
  return data;
}


console.log("Script cargado correctamente");
import { get } from "./service.js";
import { setupNewUser } from "./register.js";


const urlUsers = "http://localhost:3000/users"
const urlEvents = "http://localhost:3000/events";

const routes = {
  "/": "./users.html",
  "/login": "./login.html",
  "/register": "./register.html",
  "/event": "./event.html",
};

document.body.addEventListener("click", (e) => {
  if (e.target.matches("[data-link]")) {
    e.preventDefault();
    navigate(e.target.getAttribute("href"));
  }
});

async function navigate(pathname) {
  const route = routes[pathname];
  const html = await fetch(route).then((res) => res.text());
  document.getElementById("content").innerHTML = html;
  history.pushState({}, "", pathname);


  if (pathname == "/register") {
    setupNewUser();
  }

  if (pathname == "/event") {
    await renderEvents();
  }
}

window.addEventListener("popstate", () =>
  navigate(location.pathname)
);

navigate(location.pathname);

async function renderEvents() {
  console.log("Rendering events from renderEvents function");
  const containerEvents = document.getElementById("container-events");
  containerEvents.innerHTML = "";


  let eventData = await get(urlEvents);
  eventData.forEach(event => {
    containerEvents.innerHTML += `
      <div class="user-card" style="border: 1px solid #ccc; padding: 10px; margin: 10px; border-radius: 5px; border-color: purple;">
        <p><strong style="color: purple">Nombre:</strong> ${event.name}</p>
        <p><strong style="color: purple">Fecha:</strong>  ${event.date}</p>
        <p><strong style="color: purple">Descripción:</strong> ${event.description}</p>
        <p><strong style="color: purple">Ubicación:</strong> ${event.location}</p>
      </div>`;
  });
  console.log(eventData);

}